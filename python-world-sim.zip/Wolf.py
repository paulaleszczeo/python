from Animal import Animal
from Config import Config


class Wolf(Animal):
    def __init__(self, world):
        super().__init__(world, Config.wolf_init, Config.wolf_str)

    def create_child_on_pos(self, pos):
        child = Wolf(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)
