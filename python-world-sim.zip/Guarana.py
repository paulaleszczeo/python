from Plant import Plant
from Config import Config
from ActionResult import ActionResult


class Guarana(Plant):
    def __init__(self, world):
        super().__init__(world, Config.guarana_init, Config.guarana_str)

    def defend_from(self, attacker):
        attacker.increase_initiative(3)
        return ActionResult.PLANT_ENCOUNTERED

    def create_child_on_pos(self, pos):
        child = Guarana(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)

