import tkinter as tk
from tkinter.ttk import Frame, Button, Style
from tkinter import simpledialog
from Config import Config
from Vector2 import Vector2
from Logger import Logger


class MainWindow(Frame):

    def __init__(self, world_ref):
        super().__init__()
        self.world_ref = world_ref
        self.initUI()

    def initUI(self):
        self.master.title("Buttons")
        self.style = Style()
        self.style.theme_use("default")

        # TOP FRAME
        top_frame = Frame(self)
        self.world_canvas = tk.Canvas(top_frame, width=300, height = 300)
        self.world_canvas.bind("<Button-1>", lambda e: self.world_canvas_click(e.x//20, e.y//20))
        self.redraw_world()


        self.world_canvas.pack(fill=tk.BOTH, side=tk.LEFT)

        # BUTTON FRAME
        button_frame = Frame(top_frame, width=100)
        play_turn_button = Button(button_frame, text="play_turn" , command=lambda: self.play_turn_button_click())
        play_turn_button.bind("<KeyPress>", lambda e: self.keydown(e))
        skill_button = Button(button_frame, text="use_skill" , command=lambda: self.use_skill_button_click())
        save_button = Button(button_frame, text="Save", command=lambda: self.save_button_click())
        load_button = Button(button_frame, text="Load", command=lambda: self.load_button_click())

        play_turn_button.pack()
        skill_button.pack()
        save_button.pack()
        load_button.pack()
        button_frame.pack(side=tk.LEFT)
        # END BUTTON FRAME
        top_frame.pack(fill = tk.BOTH)
        # END TOP FRAME

        # BOTTOM FRAME
        self.log_area = tk.Text(self, height=50)
        self.log_area.pack()
        Logger.set_target(self.log_area)
        # END BOTTOM FRAME

        self.pack(fill=tk.BOTH, expand=True)

    def world_canvas_click(self, x, y):
        if self.world_ref.get_field_at(Vector2(x, y)) is None:
            result = simpledialog.askstring(str(Vector2(x,y)), "Podaj nazwe organizmu")
            self.world_ref.string_to_animal(result, Vector2(x, y))
            self.redraw_world()

    def play_turn_button_click(self):
        self.world_ref.play_turn()
        self.redraw_world()

    def use_skill_button_click(self):
        self.world_ref.set_human_skill_status()

    def save_button_click(self):
        name = simpledialog.askstring("Save", "Write name of a save")
        self.world_ref.save(name)

    def load_button_click(self):
        name = simpledialog.askstring("Save", "Write name of a save")
        self.world_ref.load(name)
        self.redraw_world()

    def keydown(self, e):
        Logger.log(e.char)
        if e.char in  ['a', 'd', 'w', 's']:
            self.world_ref.set_human_direction(e.char)

    def left_key(self, event):
        self.world_ref.set_human_direction('a')

    def right_key(self, event):
        self.world_ref.set_human_direction('d')

    def up_key(self, event):
        self.world_ref.set_human_direction('w')

    def down_key(self, event):
        self.world_ref.set_human_direction('s')

    def redraw_world(self):
        self.world_canvas.delete('all')
        for x in range(self.world_ref.w):
            for y in range(self.world_ref.h):
                org = self.world_ref.get_field_at(Vector2(x, y))
                if(org is not None):
                    self.world_canvas.create_image(x*20,y*20, anchor=tk.NW, image=Config.image_map[type(org).__name__])
                    self.world_canvas.create_image(x*20,y*20, anchor=tk.NW, image=Config.image_map["Empty"])
