from Plant import Plant
from Vector2 import Vector2
from Config import Config
from Cybersheep import Cybersheep
import random


class Hogweed(Plant):
    def __init__(self, world):
        super().__init__(world, Config.hogweed_init, Config.hogweed_str)

    def create_child_on_pos(self, pos):
        child = Hogweed(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)

    def act(self):
        dirr1 = random.randint(1, 8)
        vec1 = Vector2.direction(dirr1) + self.get_position()
        for x in range(9):
            if vec1.in_bounds(self._world.w, self._world.h):
                neighbour1= self._world.get_field_at(vec1)
                if neighbour1 is not None and isinstance(neighbour1, Hogweed) == False and \
                    isinstance(neighbour1, Cybersheep) ==  False:
                    neighbour1.kill()
                dirr1 = (dirr1 + 1) % 8
                vec1= Vector2.direction(dirr1) + self.get_position()

        will_spread = random.randint(0, 100) < 20
        dirr = 0
        vec = None
        if will_spread:
            dirr = random.randint(0, 8)
            vec = Vector2.direction(dirr) + self.get_position()
            for x in range(9):
                if not vec.in_bounds(self._world.w, self._world.h):
                    dirr = (dirr + 1) % 8
                    vec = Vector2.direction(dirr) + self.get_position()
                else:
                    neighbour = self._world.get_field_at(vec)
                    if neighbour is not None:
                        dirr = (dirr + 1) % 8
                        vec = Vector2.direction(dirr) + self.get_position()
                    else:
                        self.create_child_on_pos(vec)
                        break
