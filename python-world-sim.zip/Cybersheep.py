from Animal import Animal
from Vector2 import Vector2
from Config import Config


class Cybersheep(Animal):
    def __init__(self, world):
        super().__init__(world, Config.cybersheep_init, Config.cybersheep_str)

    def act(self):
        hogweed = self._world.get_nearest_hogweed(self.get_position())
        if hogweed is not None:
            xdist = hogweed.get_position().x - self.get_position().x
            ydist = hogweed.get_position().y - self.get_position().y
            if xdist > 0 and ydist > 0:
                pos = self.get_position() + Vector2(1,1)
                self._world.move(self, pos)
            elif xdist > 0 and ydist == 0:
                pos = self.get_position() + Vector2(1,0)
                self._world.move(self, pos)
            elif xdist == 0 and ydist > 0:
                pos = self.get_position() + Vector2(0,1)
                self._world.move(self, pos)
            elif xdist < 0 and ydist < 0:
                pos = self.get_position() + Vector2(-1,-1)
                self._world.move(self, pos)
            elif xdist < 0 and ydist == 0:
                pos = self.get_position() + Vector2(-1,0)
                self._world.move(self, pos)
            elif xdist == 0 and ydist < 0:
                pos = self.get_position() + Vector2(0,-1)
                self._world.move(self, pos)
            elif xdist > 0 and ydist < 0:
                pos = self.get_position() + Vector2(1,-1)
                self._world.move(self, pos)
            elif xdist < 0 and ydist > 0:
                pos = self.get_position() + Vector2(-1,1)
                self._world.move(self, pos)
        else:
            target = Vector2.random_direction() + self.get_position()
            while not target.in_bounds(self._world.w, self._world.h):
                target = Vector2.random_direction() + self.get_position()
            self._world.move(self, target)