from Animal import Animal
from Config import Config
from HumanSkillStatus import HumanSkillStatus
from Vector2 import Vector2
from Logger import Logger
import random


class Human(Animal):
    def __init__(self, world):
        super().__init__(world, Config.human_init, Config.human_str)
        self.__skill_status = HumanSkillStatus.SKILL_ACTIVE
        self.__skill_counter = 0
        self.__direction = Vector2.direction(1)
        self._initiative = Config.human_init

    def set_direction(self, dirr):
        if dirr == 's':
            self.__direction = Vector2(0,1)
        elif dirr == 'a':
            self.__direction = Vector2(-1,0)
        elif dirr == 'd':
            self.__direction = Vector2(1,0)
        elif dirr == 'w':
            self.__direction = Vector2(0,-1)

        Logger.log("Human direction set to " + dirr)

    def act(self):
        if(self.__skill_status == HumanSkillStatus.SKILL_ACTIVE):
            Logger.log("Human skill active: " + str(self.__skill_counter))
            will_antelope = random.randint(0,100) < 50
            if self.__skill_counter < 3 or will_antelope is True:
                target = self.__direction * 2 + self.get_position()
                if target.in_bounds(self._world.w, self._world.h):
                    self._world.move(self, target)
                    Logger.log("Human jumped to " + str(target))
            else:
                target = self.__direction + self.get_position()
                if target.in_bounds(self._world.w, self._world.h):
                    self._world.move(self, target)
            self.__skill_counter=self.__skill_counter + 1
            if self.__skill_counter == 5:
                self.__skill_status = HumanSkillStatus.SKILL_COOL_DOWN
                self.__skill_counter = 0
        else:
            if self.__skill_status == HumanSkillStatus.SKILL_COOL_DOWN:
                Logger.log("Human skill cooldown: " + str(self.__skill_counter))
                self.__skill_counter=self.__skill_counter + 1
                if self.__skill_counter == 5:
                    self.__skill_status = HumanSkillStatus.SKILL_READY
                    self.__skill_counter = 0
                    Logger.log("Human skill ready")

            target = self.__direction + self.get_position()
            if target.in_bounds(self._world.w, self._world.h):
                self._world.move(self, target)

    def get_skill_status(self):
        return self.__skill_status

    def get_skill_counter(self):
        return self.__skill_counter

    def set_skill_counter(self, sc):
        self.__skill_counter = sc

    def set_skill_status(self, ss):
        self.__skill_status = ss

    def __str__(self):
        return type(self).__name__ + ' ' + str(self._strength) + ' ' + str(self.pos.x) + \
                ' ' + str(self.pos.y) + ' ' + str(self._age) + ' ' + \
                str(self._initiative) + ' ' + str(self.__skill_counter) + \
                ' ' + str(self.__skill_status)
