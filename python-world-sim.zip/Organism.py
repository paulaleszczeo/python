from ActionResult import ActionResult
from Vector2 import Vector2

class Organism:

    def __init__(self, world, initiative, strength):
        self._world = world
        self._initiative = initiative
        self._strength = strength
        self._alive = True
        self._age = 0

    def defend_from(self, attacker):
        return ActionResult.METHOD_NOT_IMPLEMENTED

    def kill(self):
        self._alive = False

    def is_alive(self):
        return self._alive

    def get_strength(self):
        return self._strength

    def get_initiative(self):
        return self._initiative

    def get_position(self):
        return self.pos

    def set_position(self, newpos):
        self.pos = newpos

    def increase_initiative(self, coef):
        self._initiative += coef

    def increase_age(self):
        self._age += 1

    def get_age(self):
        return self._age

    def __str__(self):
        return type(self).__name__ + ' ' + str(self._strength) + ' ' + str(self.pos.x) + \
                ' ' + str(self.pos.y) + ' ' + str(self._age) + ' ' + \
                str(self._initiative)


    # def create_child_on_pos(self, pos):
    #     pass
