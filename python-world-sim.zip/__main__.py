# from World import World
import tkinter as tk
root = tk.Tk()
from UI import MainWindow
from World import World

# w = World(w=5, h=10)
# print(w.field[4][5])



w = World(15, 15)
main_window = MainWindow(w)
root.mainloop()
