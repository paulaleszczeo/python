from Organism import Organism
from ActionResult import ActionResult
from Vector2 import Vector2

class Animal(Organism):

    def act(self):
        target = Vector2.random_direction() + self.get_position()
        while not target.in_bounds(self._world.w, self._world.h):
            target = Vector2.random_direction() + self.get_position()
        self._world.move(self, target)

    def defend_from(self, attacker):
        if isinstance(attacker, type(self)):
            return ActionResult.MATE_ENCOUNTERED
        if attacker.get_strength() >= self.get_strength():
            return ActionResult.ATTACKER_WON
        else:
            return ActionResult.ATTACKER_LOST

    def __init__(self, world, initiative, strength):
        super().__init__(world, initiative, strength)

    def set_initiative(self, initiative):
        self._initiative = initiative

    def set_strength(self, strength):
        self._strength = strength

    def set_age(self, age):
        self._age = age
