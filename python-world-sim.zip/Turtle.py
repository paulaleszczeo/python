from Animal import Animal
from Config import Config
from ActionResult import ActionResult
from Vector2 import Vector2
import random



class Turtle(Animal):
    def __init__(self, world):
        super().__init__(world, Config.turtle_init, Config.turtle_str)

    def defend_from(self, attacker):
        if isinstance(attacker, Turtle):
            return ActionResult.MATE_ENCOUNTERED
        if attacker.get_strength() > 5:
            return ActionResult.ATTACKER_WON
        else:
            return ActionResult.ATTACKER_LOST

    def act(self):
        will_move = random.randint(0, 100) < 25
        if will_move:
            target = Vector2.random_direction() + self.get_position()
            while not target.in_bounds(self._world.w,self._world.h):
                target = Vector2.random_direction() + self.get_position()
            self._world.move(self, target)

    def create_child_on_pos(self, pos):
        child = Turtle(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)
