from PIL import Image, ImageTk

class Config:

    image_map = {
        "Antelope"  :ImageTk.PhotoImage(Image.open("resources/antelope.png").resize((19, 19), Image.ANTIALIAS)),
        "Sheep"  :ImageTk.PhotoImage(Image.open("resources/sheep.png").resize((19, 19), Image.ANTIALIAS)),
        "Clear"  :ImageTk.PhotoImage(Image.open("resources/clear.png").resize((19, 19), Image.ANTIALIAS)),
        "Empty"     :ImageTk.PhotoImage(Image.open("resources/empty.png").resize((19, 19), Image.ANTIALIAS)),
        "Wolf"      :ImageTk.PhotoImage(Image.open("resources/wolf.png").resize((19, 19), Image.ANTIALIAS)),
        "Hogweed"      :ImageTk.PhotoImage(Image.open("resources/hogweed.png").resize((19, 19), Image.ANTIALIAS)),
        "Human"      :ImageTk.PhotoImage(Image.open("resources/human.png").resize((19, 19), Image.ANTIALIAS)),
        "Fox"      :ImageTk.PhotoImage(Image.open("resources/fox.png").resize((19, 19), Image.ANTIALIAS)),
        "Turtle"      :ImageTk.PhotoImage(Image.open("resources/turtle.png").resize((19, 19), Image.ANTIALIAS)),
        "DeadlyNightshade"      :ImageTk.PhotoImage(Image.open("resources/nightshade.png").resize((19, 19), Image.ANTIALIAS)),
        "Guarana"      :ImageTk.PhotoImage(Image.open("resources/guarana.png").resize((19, 19), Image.ANTIALIAS)),
        "Grass"      :ImageTk.PhotoImage(Image.open("resources/grass.png").resize((19, 19), Image.ANTIALIAS)),
        "Dandelion"      :ImageTk.PhotoImage(Image.open("resources/dandelion.png").resize((19, 19), Image.ANTIALIAS)),
        "Cybersheep"      :ImageTk.PhotoImage(Image.open("resources/cyberowca.png").resize((19, 19), Image.ANTIALIAS))
    }

    MINIMUM_AGE_TO_MATE = 5

    move_up_key = 72
    move_down_key = 80
    move_left_key = 75
    move_right_key = 77

    # OCCURENCES( in % )
    antylope_occurs = 1
    fox_occurs = 1
    sheep_occurs = 1
    turtle_occurs = 1
    wolf_occurs = 1
    dandelion_occurs = 1
    nightshade_occurs = 1
    grass_occurs = 1
    guarana_occurs = 1
    hogweed_occurs = 1

    #ANIMALS
    antylope_init = 4
    antylope_str = 4

    fox_symbol = 'F'
    fox_init = 7
    fox_str = 3

    sheep_symbol = 'S'
    sheep_init = 4
    sheep_str = 4

    cybersheep_init = 4
    cybersheep_str = 11

    turtle_symbol = 'T'
    turtle_init = 1
    turtle_str = 2

    wolf_symbol = 'W'
    wolf_init = 5
    wolf_str = 9

    human_symbol = 'H'
    human_init = 4
    human_str = 5

    #PLANTS
    dandelion_symbol = 'd'
    dandelion_init = 0
    dandelion_str = 0

    nightshade_symbol = 'n'
    nightshade_init = 0
    nightshade_str = 99

    grass_symbol = '/'
    grass_init = 0
    grass_str = 0

    guarana_symbol = 'g'
    guarana_init = 0
    guarana_str = 0

    hogweed_init = 0
    hogweed_str = 10