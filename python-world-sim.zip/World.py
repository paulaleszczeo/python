from Vector2 import Vector2
from Organism import Organism
from ActionResult import ActionResult
from Turtle import Turtle
from Config import Config
from Wolf import Wolf
from Sheep import Sheep
from Hogweed import Hogweed
from Antelope import Antelope
from Cybersheep import Cybersheep
from Dandelion import Dandelion
from DeadlyNightshade import DeadlyNightshade
from Fox import Fox
from Grass import Grass
from Guarana import Guarana
from Human import Human
from HumanSkillStatus import HumanSkillStatus
from Logger import Logger
import random



class World:

        def __init__(self, w, h):
                self.__h = h
                self.__w = w
                self.__turnCounter = 0
                self.__field = [[None for _ in range(h)] for _ in range(w)]
                self.__organisms = []
                self.__new_young_organisms = []
                self.__dead_organisms = []
                self.__human_ref = Human(self)
                self.populate_world()

        def populate_world(self):
                self.add_org_on_rand_pos(self.__human_ref)
                world_size = self.w * self.h

                for _ in range((world_size * Config.wolf_occurs)//100):
                        self.add_org_on_rand_pos(Wolf(self))

                for _ in range((world_size * Config.sheep_occurs)//100):
                        self.add_org_on_rand_pos(Sheep(self))
                for _ in range((world_size * Config.antylope_occurs)//100):
                        self.add_org_on_rand_pos(Antelope(self))
                for _ in range((world_size * Config.fox_occurs)//100):
                        self.add_org_on_rand_pos(Fox(self))
                self.add_org_on_rand_pos(Dandelion(self))
                self.add_org_on_rand_pos(Grass(self))
                for _ in range((world_size * Config.turtle_occurs)//100):
                        self.add_org_on_rand_pos(Turtle(self))
                self.add_org_on_rand_pos(Guarana(self))
                self.add_org_on_rand_pos(DeadlyNightshade(self))
                self.add_org_on_rand_pos(Cybersheep(self))
                self.add_org_on_rand_pos(Hogweed(self))

        @property
        def w(self):
                return self.__w

        @property
        def h(self):
                return self.__h

        @property
        def field(self):
                return self.__field

        def play_turn(self):
                self.__turnCounter += 1
                for org in self.__organisms:
                        if org.is_alive():
                                org.act()
                                org.increase_age()

                while len(self.__dead_organisms) > 0:
                        self.__organisms.remove(self.__dead_organisms.pop())

                while len(self.__new_young_organisms) > 0:
                        self.__organisms.append(self.__new_young_organisms.pop())
                self.__organisms.sort(key = lambda x: x._initiative)

        def field_empty(self, x: int, y:int):
                x_valid = 0 <= x < self.w
                y_valid = 0 <= y < self.h
                return x_valid and y_valid and self.field[x][y] is None

        def get_field_at(self, pos: Vector2):
                return self.__field[pos.x][pos.y]

        def set_field_at(self, pos, org):
                self.__field[pos.x][pos.y] = org

        def clear_field_at(self, pos):
                self.__field[pos.x][pos.y] = None

        def remove_organism(self, org):
                # org = self.get_field_at(org.get_position())
                self.__dead_organisms.append(org)
                org.kill()
                self.clear_field_at(org.get_position())

        def add_org(self, org):
                self.__organisms.append(org)
                self.set_field_at(org.get_position(), org)

        def add_org_on_rand_pos(self, org):
                self.__organisms.append(org)

                pos = Vector2.random_point(self.w-1, self.h-1)
                while (self.get_field_at(pos) != None):
                      pos = Vector2.random_point(self.w-1, self.h-1)
                org.set_position(pos)
                self.set_field_at(org.get_position(), org)

        def add_young_org(self, org):
                self.__new_young_organisms.append(org)
                self.set_field_at(org.get_position(), org)

        def set_human_direction(self, direct):
                self.__human_ref.set_direction(direct)

        def set_human_skill_status(self):
                if self.__human_ref.get_skill_status() == HumanSkillStatus.SKILL_READY and self.__human_ref.is_alive():
                        self.__human_ref.set_skill_status(HumanSkillStatus.SKILL_ACTIVE)
                        Logger.log("Skill activated")
                elif self.__human_ref.get_skill_status() == HumanSkillStatus.SKILL_COOL_DOWN and self.__human_ref.is_alive():
                        Logger.log("You can't use skill now")
                elif self.__human_ref.get_skill_status() == HumanSkillStatus.SKILL_ACTIVE and self.__human_ref.is_alive():
                        Logger.log("You are already using skill")
                elif not self.__human_ref.is_alive():
                        Logger.log("You're dead")
                
        def get_nearest_hogweed(self, pos):
                nearest_hogweed = None
                for o in self.__organisms:
                        if isinstance(o, Hogweed):
                                if nearest_hogweed is None or \
                                pos.dist(o.get_position()) < pos.dist(nearest_hogweed.get_position()):
                                        nearest_hogweed = o
                return nearest_hogweed

        def move(self, moving_animal, newpos):
                target = self.get_field_at(newpos)
                if target is None:
                        self.clear_field_at(moving_animal.get_position())
                        moving_animal.set_position(newpos)
                        self.set_field_at(moving_animal.get_position(), moving_animal)
                else:
                        defense_result = target.defend_from(moving_animal)
                        if defense_result == ActionResult.ATTACKER_WON:
                                self.remove_organism(target)
                                #LOGGER
                                Logger.log(type(moving_animal).__name__ + " killed " + type(target).__name__ + ' at ' + str(newpos))
                                self.clear_field_at(moving_animal.get_position())
                                moving_animal.set_position(newpos)
                                self.set_field_at(moving_animal.get_position(), moving_animal)
                        elif defense_result == ActionResult.ATTACKER_LOST:
                                #LOGGER
                                Logger.log(type(moving_animal).__name__ + " attacked " + type(target).__name__ + " and lost at " + str(newpos))
                                if not isinstance(target, Turtle):
                                        self.remove_organism(moving_animal)

                        elif defense_result == ActionResult.TARGET_ESCAPED:
                                self.clear_field_at(moving_animal.get_position())
                                moving_animal.set_position(newpos)
                                self.set_field_at(moving_animal.get_position(), moving_animal)
                        elif defense_result == ActionResult.PLANT_ENCOUNTERED:
                                self.remove_organism(target)
                                self.clear_field_at(moving_animal.get_position())
                                moving_animal.set_position(newpos)
                                self.set_field_at(moving_animal.get_position(), moving_animal)
                        elif defense_result == ActionResult.MATE_ENCOUNTERED \
                        and moving_animal.get_age() >= Config.MINIMUM_AGE_TO_MATE \
                        and target.get_age() >= Config.MINIMUM_AGE_TO_MATE:
                                d = random.randint(0,8)
                                pos = Vector2.direction(d) + moving_animal.get_position()
                                for x in range(9):
                                        if not pos.in_bounds(self.w, self.h):
                                                d = (d + 1) % 8
                                                pos = Vector2.direction(d) + moving_animal.get_position()
                                        else:
                                                neighbour = self.get_field_at(pos)
                                                if neighbour is not None:
                                                        d = (d + 1) % 8
                                                        pos = Vector2.direction(d) + moving_animal.get_position()
                                                else:
                                                        moving_animal.create_child_on_pos(pos)
                                                        Logger.log(type(moving_animal).__name__ + " created child with " + \
                                                        type(target).__name__ + " at " + str(pos))
                                                        break

        def string_to_animal(self, name, pos):
                new_org = None
                if name == 'antelope':
                        new_org = Antelope(self)
                elif name == 'wolf':
                        new_org = Wolf(self)
                elif name == 'cybersheep':
                        new_org = Cybersheep(self)
                elif name == 'dandelion':
                        new_org = Dandelion(self)
                elif name == 'nightshade':
                        new_org = DeadlyNightshade(self)
                elif name == 'fox':
                        new_org = Fox(self) 
                elif name == 'grass':
                        new_org = Grass(self)
                elif name == 'guarana':
                        new_org = Guarana(self)  
                elif name == 'hogweed':
                        new_org = Hogweed(self)  
                elif name == 'sheep':
                        new_org = Sheep(self)  
                elif name == 'turtle':
                        new_org = Turtle(self)  
                if new_org is not None:
                        new_org.set_position(pos)
                        self.__new_young_organisms.append(new_org)
                        self.set_field_at(pos, new_org)      

        def save(self, fname):
                with open( fname + '.txt', 'w') as file:
                        for o in self.__organisms:
                                file.write(str(o) + '\n')
        
        def load(self, fname):
                self.__field = [[None for _ in range(self.h)] for _ in range(self.w)]
                self.__organisms.clear()
                self.__new_young_organisms.clear()
                self.__dead_organisms.clear()
                with open(fname+'.txt', 'r') as file:
                     for line in file:
                                values = line.split()
                                new_org = None
                                if values[0] == 'Human':
                                        new_org = Human(self)
                                        new_org.set_strength(int(values[1]))
                                        new_org.set_position(Vector2(int(values[2]), int(values[3])))
                                        new_org.set_age(int(values[4]))
                                        new_org.set_initiative(int(values[5]))
                                        new_org.set_skill_counter(int(values[6]))
                                        new_org.set_skill_status(values[7])
                                else:
                                        if values[0] == 'Wolf':
                                                new_org = Wolf(self)
                                        elif values[0] == 'Antelope':
                                                new_org = Antelope(self)
                                        elif values[0] == 'Fox':
                                                new_org = Fox(self)
                                        elif values[0] == 'Sheep':
                                                new_org = Sheep(self)
                                        elif values[0] == 'Cybersheep':
                                                new_org = Cybersheep(self)
                                        elif values[0] == 'Turtle':
                                                new_org = Turtle(self)
                                        elif values[0] == 'Dandelion':
                                                new_org = Dandelion(self)
                                        elif values[0] == 'Grass':
                                                new_org = Grass(self)
                                        elif values[0] == 'Guarana':
                                                new_org = Guarana(self)
                                        elif values[0] == 'Hogweed':
                                                new_org = Hogweed(self)
                                        elif values[0] == 'DeadlyNightshade':
                                                new_org = DeadlyNightshade(self)
                                        new_org.set_strength(int(values[1]))
                                        new_org.set_position(Vector2(int(values[2]), int(values[3])))
                                        new_org.set_age(int(values[4]))
                                        new_org.set_initiative(int(values[5]))
                                self.__organisms.append(new_org)

                                                