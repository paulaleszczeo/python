from Organism import Organism
from ActionResult import ActionResult
import random
from Vector2 import Vector2


class Plant(Organism):

    def __init__(self, world, initiative, strength):
        super().__init__( world, initiative, strength)

    def defend_from(self, attacker):
        return ActionResult.PLANT_ENCOUNTERED

    def act(self):
        will_spread = random.randint(0,100) < 30
        d = 0
        vec = None
        if will_spread:
            d = random.randint(0,8)
            vec = Vector2.direction(d) + self.get_position()
            for x in range(9):
                if not vec.in_bounds(self._world.w, self._world.h):
                    d = (d + 1) % 8
                    vec = Vector2.direction(d) + self.get_position()
                else:
                    neighbour = self._world.get_field_at(vec)
                    if neighbour is not None:
                        d = (d + 1) % 8
                        vec = Vector2.direction(d) + self.get_position()
                    else:
                        self.create_child_on_pos(vec)
                        break

    def set_initiative(self, initiative):
        self._initiative = initiative

    def set_strength(self,strength):
        self._strength = strength

    def set_age(self, age):
        self._age = age

    def create_child_on_pos(self, pos):
        pass
