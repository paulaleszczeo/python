from enum import Enum
class HumanSkillStatus(Enum):
    SKILL_READY = 1
    SKILL_ACTIVE = 2
    SKILL_COOL_DOWN = 3