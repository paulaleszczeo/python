from Plant import Plant
from Config import Config


class Grass(Plant):
    def __init__(self, world):
        super().__init__(world, Config.grass_init, Config.grass_str)

    def create_child_on_pos(self, pos):
        child = Grass(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)
