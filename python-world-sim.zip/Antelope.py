from Animal import Animal
from ActionResult import ActionResult
from Config import Config
from Vector2 import Vector2
import random


class Antelope(Animal):
    def __init__(self, world):
        super().__init__(world, Config.antylope_init, Config.antylope_str)

    def act(self):
        target = Vector2.random_direction() * 2 + self.get_position()
        while not target.in_bounds(self._world.w, self._world.h):
            target = Vector2.random_direction() * 2 + self.get_position()
        self._world.move(self, target)

    def defend_from(self, attacker):
        escape = random.randint(0, 100) < 50
        if isinstance(attacker, Antelope):
            return ActionResult.MATE_ENCOUNTERED
        if attacker.get_strength() >= self.get_strength():
            if escape:
                return ActionResult.TARGET_ESCAPED
            else:
                return ActionResult.ATTACKER_WON
        else:
            return ActionResult.ATTACKER_LOST

    def create_child_on_pos(self, pos):
        child = Antelope(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)
