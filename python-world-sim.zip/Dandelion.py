from Plant import Plant
from Config import Config
import random
from Vector2 import Vector2


class Dandelion(Plant):
    def __init__(self, world):
        super().__init__(world, Config.dandelion_init, Config.dandelion_str)

    def create_child_on_pos(self,pos):
        child = Dandelion(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)

    def act(self):
        will_spread = random.randint(0, 100) < 30
        if will_spread:
            d = random.randint(0,8)
            vec = Vector2.direction(d) + self.get_position()
            for x in range(3):
                for y in range(9):
                    if not vec.in_bounds(self._world.w, self._world.h):
                        d = (d + 1) % 8
                        vec = Vector2.direction(d) + self.get_position()
                    else:
                        neighbour = self._world.get_field_at(vec)
                        if neighbour is not None:
                            d = (d + 1) % 8
                            vec = Vector2.direction(d) + self.get_position()
                        else:
                            self.create_child_on_pos(vec)
                            break
