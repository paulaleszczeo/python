from tkinter import INSERT


class Logger:
    textArea = None

    @staticmethod
    def set_target(target):
        Logger.textArea = target

    @staticmethod
    def log(message):
        if Logger.textArea != None:
            Logger.textArea.insert(INSERT, message + "\n")