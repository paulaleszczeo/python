import random


class Vector2:

    direction_map = None

    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    @staticmethod
    def random_direction():
        while True:
            x=random.randint(-1,1)
            y=random.randint(-1,1)
            if x != 0 or y != 0:
                break
        return Vector2(x,y)

    @staticmethod
    def random_point(max_x,max_y):
        return Vector2(random.randint(0,max_x),random.randint(0,max_y))

    @staticmethod
    def direction(d):
        return Vector2.direction_map[d]

    def dist(self, vect):
        return ((self.x - vect.x)**2 + (self.y - vect.y)**2)**(0.5)

    def in_bounds(self, x_max, y_max, x_min=0, y_min=0):
        return 0 <= self.x < x_max and 0 <= self.y < y_max

#https://www.geeksforgeeks.org/operator-overloading-in-python/
    def __mul__(self, other):
        return Vector2(self.x*other, self.y*other)

    def __add__(self, other):
        return Vector2(self.x+other.x, self.y+other.y)

    def __str__(self):
        return "(" + str(self.x) + ", " + str(self.y) + ")"

Vector2.direction_map = {
            0: Vector2(0, 0),
            1: Vector2(-1, 0),
            2: Vector2(0, -1),
            3: Vector2(-1, -1),
            4: Vector2(1, 0),
            5: Vector2(0, 1),
            6: Vector2(1, 1),
            7: Vector2(-1, 1),
            8: Vector2(1, -1)
        }
