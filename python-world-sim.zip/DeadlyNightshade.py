from Plant import Plant
from Config import Config
from ActionResult import ActionResult


class DeadlyNightshade(Plant):
    def __init__(self, world):
        super().__init__(world, Config.nightshade_init, Config.nightshade_str)

    def defend_from(self, attacker):
        return ActionResult.ATTACKER_LOST

    def create_child_on_pos(self, pos):
        child = DeadlyNightshade(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)
