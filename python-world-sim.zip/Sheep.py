from Animal import Animal
from Config import Config


class Sheep(Animal):
    def __init__(self, world):
        super().__init__(world, Config.sheep_init, Config.sheep_str)

    def create_child_on_pos(self, pos):
        child = Sheep(self._world)
        child.set_position(pos)
        self._world.add_young_org(child)
