from enum import Enum


class ActionResult(Enum):
    ATTACKER_WON = 1
    ATTACKER_LOST = 2
    TARGET_ESCAPED = 3
    PLANT_ENCOUNTERED = 4
    MATE_ENCOUNTERED = 5
    METHOD_NOT_IMPLEMENTED = 6
